package CustomerBilling2;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;
import javax.swing.text.JTextComponent;

import com.ibm.icu.util.Calendar;

import java.awt.Color;
import java.awt.Component;
import java.awt.TextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.JCheckBox;
import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseWheelListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.awt.event.MouseWheelEvent;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.DefaultComboBoxModel;

public class CustomerBilling2 extends JFrame {

	protected static final String JOption = null;
	protected static final String Calender = null;
	private JPanel contentPane;
	protected String iTotal;
	private final Action action = new SwingAction();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CustomerBilling2 frame = new CustomerBilling2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CustomerBilling2() {
	
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 1400, 800);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(176, 224, 230));
		panel.setBorder(new MatteBorder(14, 14, 14, 14, (Color) new Color(0, 139, 139)));
		panel.setBounds(26, 10, 1360, 700);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(41, 27, 405, 503);
		panel_1.setBorder(new MatteBorder(14, 14, 14, 14, (Color) new Color(0, 139, 139)));
		panel_1.setBackground(new Color(176, 224, 230));
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		TextField textField = new TextField();
		textField.setBounds(218, 30, 166, 25);
		panel_1.add(textField);
		
		JLabel lblNewLabel = new JLabel("CustomerRef");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblNewLabel.setBounds(24, 30, 166, 25);
		panel_1.add(lblNewLabel);
		
		JLabel lblFirstname = new JLabel("Firstname");
		lblFirstname.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblFirstname.setBounds(24, 61, 166, 25);
		panel_1.add(lblFirstname);
		
		TextField textField_1 = new TextField();
		textField_1.setBounds(218, 61, 166, 25);
		panel_1.add(textField_1);
		
		JLabel lblSurname = new JLabel("Surname");
		lblSurname.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblSurname.setBounds(24, 92, 166, 25);
		panel_1.add(lblSurname);
		
		TextField textField_2 = new TextField();
		textField_2.setBounds(218, 92, 166, 25);
		panel_1.add(textField_2);
		
		JLabel lblAddress = new JLabel("Address");
		lblAddress.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblAddress.setBounds(24, 123, 166, 25);
		panel_1.add(lblAddress);
		
		TextField textField_3 = new TextField();
		textField_3.setBounds(218, 123, 166, 25);
		panel_1.add(textField_3);
		
		JLabel lblPostCode = new JLabel("Post Code");
		lblPostCode.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblPostCode.setBounds(24, 161, 166, 25);
		panel_1.add(lblPostCode);
		
		TextField textField_4 = new TextField();
		textField_4.setBounds(218, 161, 166, 25);
		panel_1.add(textField_4);
		
		JLabel lblMobile = new JLabel("Mobile");
		lblMobile.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblMobile.setBounds(24, 200, 166, 25);
		panel_1.add(lblMobile);
		
		TextField textField_1_1 = new TextField();
		textField_1_1.setBounds(218, 200, 166, 25);
		panel_1.add(textField_1_1);
		
		JLabel lblEmail = new JLabel("Email");
		lblEmail.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblEmail.setBounds(24, 235, 166, 25);
		panel_1.add(lblEmail);
		
		TextField textField_2_1 = new TextField();
		textField_2_1.setBounds(218, 235, 166, 25);
		panel_1.add(textField_2_1);
		
		JLabel lblNationality = new JLabel("Nationality");
		lblNationality.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblNationality.setBounds(24, 270, 166, 25);
		panel_1.add(lblNationality);
		
		JLabel lblDateOfBirth = new JLabel("Date of birth");
		lblDateOfBirth.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblDateOfBirth.setBounds(24, 305, 166, 25);
		panel_1.add(lblDateOfBirth);
		
		TextField textField_5 = new TextField();
		textField_5.setBounds(218, 305, 166, 25);
		panel_1.add(textField_5);
		
		JLabel lblTypeOfId = new JLabel("Type of ID");
		lblTypeOfId.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblTypeOfId.setBounds(24, 340, 166, 25);
		panel_1.add(lblTypeOfId);
		
		JLabel lblGender = new JLabel("Gender");
		lblGender.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblGender.setBounds(24, 388, 166, 25);
		panel_1.add(lblGender);
		
		JLabel lblRoomType = new JLabel("Room Type");
		lblRoomType.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblRoomType.setBounds(24, 433, 166, 25);
		panel_1.add(lblRoomType);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Kenya", "British", "Canada", "Morocco", "Iran"}));
		comboBox.setBounds(218, 270, 166, 25);
		panel_1.add(comboBox);
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"Student", "Pilot", "Driving Licence", "Passport"}));
		comboBox_1.setBounds(218, 340, 166, 25);
		panel_1.add(comboBox_1);
		
		JComboBox comboBox_2 = new JComboBox();
		comboBox_2.setModel(new DefaultComboBoxModel(new String[] {"Male", "Female"}));
		comboBox_2.setBounds(218, 388, 166, 25);
		panel_1.add(comboBox_2);
		
		JComboBox comboBox_3 = new JComboBox();
		comboBox_3.setModel(new DefaultComboBoxModel(new String[] {"Single", "Double"}));
		comboBox_3.setBounds(218, 433, 166, 25);
		panel_1.add(comboBox_3);
		
		JPanel panel_1_2 = new JPanel();
		panel_1_2.setBorder(new MatteBorder(14, 14, 14, 14, (Color) new Color(0, 139, 139)));
		panel_1_2.setBackground(new Color(176, 224, 230));
		panel_1_2.setBounds(957, 30, 374, 500);
		panel.add(panel_1_2);
		panel_1_2.setLayout(null);
		
		JTextArea textArea = new JTextArea();
		textArea.addMouseWheelListener(new MouseWheelListener() {
			public void mouseWheelMoved(MouseWheelEvent e) {
			}
		});
		textArea.setBounds(24, 23, 327, 456);
		panel_1_2.add(textArea);
		
		JPanel panel_1_2_1 = new JPanel();
		panel_1_2_1.setBounds(957, 540, 374, 133);
		panel.add(panel_1_2_1);
		panel_1_2_1.setBorder(new MatteBorder(14, 14, 14, 14, (Color) new Color(0, 139, 139)));
		panel_1_2_1.setBackground(new Color(176, 224, 230));
		panel_1_2_1.setLayout(null);
		
		JButton btnReset = new JButton("Reset");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Component jtxtKim = null;
				jtxtKim.setEnabled(false);
				Component jtxtKerry = null;
				jtxtKerry.setEnabled(false);
				Component jtxtCoffee = null;
				jtxtCoffee.setEnabled(false);
				Component jtxtSwindon = null;
				jtxtSwindon.setEnabled(false);
				Component jtxtKenya = null;
				jtxtKenya.setEnabled(false);
				Component jtxtIshan = null;
				jtxtIshan.setEnabled(false);
				Component jtxtCarlton = null;
				jtxtCarlton.setEnabled(false);
				Component jtxtLagos = null;
				jtxtLagos.setEnabled(false);
				Component jtxtYork = null;
				jtxtYork.setEnabled(false);
				Component jtxtQueen = null;
				jtxtQueen.setEnabled(false);
				
				((JTextComponent) jtxtKim).setText("0");
				((JTextComponent) jtxtKerry).setText("0");
				((JTextComponent) jtxtCoffee).setText("0");
				((JTextComponent) jtxtSwindon).setText("0");
				((JTextComponent) jtxtKenya).setText("0");
				((JTextComponent) jtxtIshan).setText("0");
				((JTextComponent) jtxtCarlton).setText("0");
				((JTextComponent) jtxtLagos).setText("0");
				((JTextComponent) jtxtYork).setText("0");
				((JTextComponent) jtxtQueen).setText("0");
				
				AbstractButton chkKimCake = null;
				chkKimCake.setSelected(false);
				AbstractButton chkKerryCake = null;
				chkKerryCake.setSelected(false);
				AbstractButton chkCoffeeCake = null;
				chkCoffeeCake.setSelected(false);
				AbstractButton chkSwindonCake = null;
				chkSwindonCake.setSelected(false);
				AbstractButton chkYorkCreamPie = null;
				chkYorkCreamPie.setSelected(false);
				AbstractButton chkIshanCreamCake = null;
				chkIshanCreamCake.setSelected(false);
				AbstractButton chkLagosChocoleteCake = null;
				chkLagosChocoleteCake.setSelected(false);
				AbstractButton chkKenyaChocoleteCake = null;
				chkKenyaChocoleteCake.setSelected(false);
				AbstractButton chkCarltonHillChocoleteCake = null;
				chkCarltonHillChocoleteCake.setSelected(false);
				AbstractButton chkQueenParkChocoleteCake = null;
				chkQueenParkChocoleteCake.setSelected(false);
				
				JTextComponent jtxtCustomerRef = null;
				jtxtCustomerRef.setText(null);
				Object Component = null;
				jtxtCustomerRef.setEnabled(false);
				int refs= 5015 + (int) (Math.random()*17238);
				String cRef = "";
				cRef += refs + 1560;
				
				jtxtCustomerRef.setText(cRef);
				JTextComponent jtxtFirstname = null;
				jtxtFirstname.setText(null);
				JTextComponent jtxtSurname = null;
				jtxtSurname.setText(null);
				JTextComponent jtxtAddress = null;
				jtxtAddress.setText(null);
				JTextComponent jtxtPostCode = null;
				jtxtPostCode.setText(null);
				jtxtAddress.setText(null);
				JTextComponent jtxtTax = null;
				jtxtTax.setText(null);
				JTextComponent jtxtMobile = null;
				jtxtMobile.setText(null);
				JTextComponent jtxtDOB = null;
				jtxtDOB.setText(null);
				JTextComponent jtxtTotal = null;
				jtxtTotal.setText(null);
				JTextComponent jtxtSubTotal = null;
				jtxtSubTotal.setText(null);
				JComboBox jcomNationality = null;
				jcomNationality.setSelectedIndex(0);
				JComboBox jcomType = null;
				jcomType.setSelectedIndex(0);
				JComboBox jcomGender = null;
				jcomGender.setSelectedIndex(0);
				JComboBox jcomRoom = null;
				jcomRoom.setSelectedIndex(0);
				
			}
		});
		btnReset.setFont(new Font("Tahoma", Font.PLAIN, 24));
		btnReset.setBounds(22, 34, 145, 66);
		panel_1_2_1.add(btnReset);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
			}
				
		
		});
		btnExit.setFont(new Font("Tahoma", Font.PLAIN, 24));
		btnExit.setBounds(177, 34, 170, 66);
		panel_1_2_1.add(btnExit);
		
		JPanel panel_1_2_1_1 = new JPanel();
		panel_1_2_1_1.setBorder(new MatteBorder(14, 14, 14, 14, (Color) new Color(0, 139, 139)));
		panel_1_2_1_1.setBackground(new Color(176, 224, 230));
		panel_1_2_1_1.setBounds(41, 540, 405, 133);
		panel.add(panel_1_2_1_1);
		panel_1_2_1_1.setLayout(null);
		
		JButton btnNewButton = new JButton("Print");
		btnNewButton.addActionListener(new ActionListener() {
			private JTextComponent jtxtReceipt;

			public void actionPerformed(ActionEvent e) {
			
				try
				{
					jtxtReceipt = null;
					jtxtReceipt.print();
				}
				catch(java.awt.print.PrinterException e1) {
					System.err.format("No Printer found", e1.getMessage());
				}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 24));
		btnNewButton.setBounds(28, 22, 170, 79);
		panel_1_2_1_1.add(btnNewButton);
		
		JButton btnTotal = new JButton("Total");
		btnTotal.addActionListener(new ActionListener() {
			private JTextComponent jtxtCoffee;
			private JTextComponent jtxtKerry;
			private JTextComponent jtxtKim;
			private double[] iteamcost;
			private JTextComponent jtxtSwindon;
			private JTextComponent jtxtYork;
			private JTextComponent jtxtIshan;
			private JTextComponent jtxtLagos;
			private JTextComponent jtxtKenya;
			private JTextComponent jtxtCarlton;
			private JTextComponent jtxtQueen;
			private String iTax;
			private String iSubTotal;
			private JTextComponent jtxtTax;
			private JTextComponent jtxtSubTotal;
			private JTextComponent jtxtTotal;
			private Component jtxtReceipt;
			private int refs;
			private Calendar timer;
			private DateFormat tdate;
			private JTextComponent jtxtKerryCake;
			private JTextComponent jtxtKimCake;
			private JTextComponent jtxCoffee;
			private JTextComponent jtxtSurname;
			private JTextComponent jtxtCustomerRef;
			private JTextComponent jtxtFirstname;
			public void actionPerformed(ActionEvent e) {
				
				jtxtKim = null;
				iteamcost = null;
				iteamcost[0] = Double.parseDouble(jtxtKim.getText()) * 1.50;
				jtxtKerry = null;
			    iteamcost[1] = Double.parseDouble(jtxtKerry.getText()) * 1.87;
				jtxtCoffee = null;
				iteamcost[2] = Double.parseDouble(jtxtCoffee.getText()) * 1.95;
				jtxtSwindon = null;
				iteamcost[3] = Double.parseDouble(jtxtSwindon.getText()) * 2.10;
				jtxtYork = null;
				iteamcost[4] = Double.parseDouble(jtxtYork.getText()) * 1.20;
				jtxtIshan = null;
				iteamcost[5] = Double.parseDouble(jtxtIshan.getText()) * 1.24;
				jtxtLagos = null;
				iteamcost[6] = Double.parseDouble(jtxtLagos.getText()) * 4.50;
				jtxtKenya = null;
				iteamcost[7] = Double.parseDouble(jtxtKenya.getText()) * 10.50;
				jtxtCarlton = null;
				iteamcost[8] = Double.parseDouble(jtxtCarlton.getText()) * 5.70;
				jtxtQueen = null;
				iteamcost[9] = Double.parseDouble(jtxtQueen.getText()) * 3.70;
				
				iteamcost[10] = iteamcost[0] + iteamcost[1] + iteamcost[2] + iteamcost[3] + iteamcost[4];
				iteamcost[11] = iteamcost[5] + iteamcost[6] + iteamcost[7] + iteamcost[8] + iteamcost[9];
				
				iteamcost[12] = iteamcost[10] + iteamcost[11];
				iTax = String.format("� %.2f" , iteamcost[12]/ 100);
				iSubTotal = String.format("� %.2f" , iteamcost[12]);
				iTotal = String.format("� %.2f" , iteamcost[12] + (iteamcost[12]/ 100));
                
				jtxtTax = null;
				jtxtTax.setText(iTax);
				jtxtSubTotal = null;
				jtxtSubTotal.setText(iSubTotal);
				jtxtTotal = null;
				jtxtTotal.setText(iTotal);
				
			 jtxtReceipt = null;
				//===========================================================================================
				jtxtReceipt.setEnabled(true);
				//==========================================================================================
				setRefs(1325 + (int) (Math.random()*4238));
				
				timer = null;
				//===========================================================================================
				timer.getTime();
				SimpleDateFormat tTime = new SimpleDateFormat("HH:mm:ss");
				tTime.format(timer.getTime());
				tdate = new SimpleDateFormat("dd-MMM-yyyy");
				tdate = null;
				tdate.format(timer.getTime());
				jtxtCustomerRef = null;
				jtxtFirstname = null;
				jtxtKimCake = null;
				jtxtKerryCake = null;
				jtxCoffee = null;
				jtxtSurname = null;
				//==========================================================================================
				((JTextArea) jtxtReceipt).append("\tCustomer Billing System\n" +
				"Reference:\t\t\t" + refs +
				"\n==============================================\t " +
				
				          "\n=============================================\t " +
				          "\nCustomer Ref:\t\t\t" + jtxtCustomerRef.getText() +
				          "\nFirstname:\t\t\t" + jtxtFirstname.getText() +
				          "\nSurname:\t\t\t" + jtxtSurname.getText() +
				          "\nKim's Cake:\t\t\t" + jtxtKimCake.getText() +
				          "\nKerry's Cake:\t\t\t" + jtxtKerryCake.getText() +
				          "\nCoffee:\t\t\t" + jtxCoffee.getText() +
				          
				          "\nSwindon Cake:\t\t\t" + jtxtSwindon.getText() +
				          "\nYork Cake:\t\t\t" + jtxtYork.getText() +
				          "\nBlack Forest Cake:\t\t\t" + jtxtIshan.getText() +
				          "\nLagos Cake:\t\t\t" + jtxtLagos.getText() +
				          "\nKilburn Cake:\t\t\t" + jtxtKenya.getText() +
				          "\nCarlton Cake:\t\t\t" + jtxtCarlton.getText() +
				          "\nQueens Cake:\t\t\t" + jtxtQueen.getText() +
				          
				          "\n=======================================================\t " +
				          
				          "\nTax:\t\t\t" + iTax +
				          "\nSub Total:\t\t\t" + iSubTotal +
				          "\nTotal:\t\t\t" + iTotal +
				          "\n========================================================\t " +
				          "\nDate: " + tdate.format(timer.getTime()) +
				                  "\t\tTime: " + tTime.format(timer.getTime()) +
				                "\n\n\tThank you for Shopping at iShop\n" );
				             
				
				
			}

			public void setRefs(int refs) {
				this.refs = refs;
			}
		});
		btnTotal.setFont(new Font("Tahoma", Font.PLAIN, 24));
		btnTotal.setBounds(208, 22, 170, 79);
		panel_1_2_1_1.add(btnTotal);
		
		JPanel panel_1_1 = new JPanel();
		panel_1_1.addMouseWheelListener(new MouseWheelListener() {
			public void mouseWheelMoved(MouseWheelEvent e) {
			}
		});
		panel_1_1.setLayout(null);
		panel_1_1.setBorder(new MatteBorder(14, 14, 14, 14, (Color) new Color(0, 139, 139)));
		panel_1_1.setBackground(new Color(176, 224, 230));
		panel_1_1.setBounds(472, 27, 475, 646);
		panel.add(panel_1_1);
		
		final JCheckBox chkKimCake = new JCheckBox("Kim's Cake");
		chkKimCake.addActionListener(new ActionListener() {
			private Component jtxtKim;

			public void actionPerformed(ActionEvent arg0) {
				
				if(chkKimCake.isSelected())
				{
					jtxtKim = null;
					jtxtKim.setEnabled(true);
					((JTextComponent) jtxtKim).setText("");
					jtxtKim.requestFocus();
				}
				else
				{
					jtxtKim.setEnabled(false);
					((JTextComponent) jtxtKim).setText("0");
					
					}
			}
		});
		chkKimCake.setBackground(new Color(176, 224, 230));
		chkKimCake.setFont(new Font("Dialog", Font.BOLD, 20));
		chkKimCake.setBounds(17, 37, 288, 25);
		panel_1_1.add(chkKimCake);
		
		TextField textField_6 = new TextField();
		textField_6.setText("              0");
		textField_6.setBounds(307, 37, 126, 25);
		panel_1_1.add(textField_6);
		
		TextField textField_6_1 = new TextField();
		textField_6_1.setText("              0");
		textField_6_1.setBounds(307, 85, 126, 25);
		panel_1_1.add(textField_6_1);

		JCheckBox chkKerryCake = new JCheckBox("Kerry's Cake");
		chkKerryCake.setBackground(new Color(176, 224, 230));
		chkKerryCake.setFont(new Font("Dialog", Font.BOLD, 20));
		chkKerryCake.setBounds(17, 85, 288, 25);
		panel_1_1.add(chkKerryCake);
		
		TextField textField_6_2 = new TextField();
		textField_6_2.setText("              0");
		textField_6_2.setBounds(307, 168, 126, 25);
		panel_1_1.add(textField_6_2);
		
		JCheckBox chkYorkCreamPie = new JCheckBox("York Cream Pie");
		chkYorkCreamPie.setBackground(new Color(176, 224, 230));
		chkYorkCreamPie.setFont(new Font("Dialog", Font.BOLD, 20));
		chkYorkCreamPie.setBounds(17, 211, 288, 25);
		panel_1_1.add(chkYorkCreamPie);
		
		TextField textField_6_3 = new TextField();
		textField_6_3.setText("              0");
		textField_6_3.setBounds(307, 127, 126, 25);
		panel_1_1.add(textField_6_3);
		
		JCheckBox chkCoffeeCake = new JCheckBox("Coffee Cake");
		chkCoffeeCake.setBackground(new Color(176, 224, 230));
		chkCoffeeCake.setFont(new Font("Dialog", Font.BOLD, 20));
		chkCoffeeCake.setBounds(17, 127, 288, 25);
		panel_1_1.add(chkCoffeeCake);
		
		TextField textField_6_4 = new TextField();
		textField_6_4.setText("              0");
		textField_6_4.setBounds(307, 211, 126, 25);
		panel_1_1.add(textField_6_4);
		
		JCheckBox chkIshanCreamCake = new JCheckBox("Ishan Cream Cake");
		chkIshanCreamCake.addMouseWheelListener(new MouseWheelListener() {
			public void mouseWheelMoved(MouseWheelEvent e) {
			}
		});
		chkIshanCreamCake.setBackground(new Color(176, 224, 230));
		chkIshanCreamCake.setFont(new Font("Dialog", Font.BOLD, 20));
		chkIshanCreamCake.setBounds(17, 252, 288, 25);
		panel_1_1.add(chkIshanCreamCake);
		
		TextField textField_6_5 = new TextField();
		textField_6_5.setText("              0");
		textField_6_5.setBounds(310, 252, 123, 25);
		panel_1_1.add(textField_6_5);
		
		JCheckBox chkbxLagosChocoleteCake = new JCheckBox("Lagos Chocolete Cake");
		chkbxLagosChocoleteCake.setBackground(new Color(176, 224, 230));
		chkbxLagosChocoleteCake.setFont(new Font("Dialog", Font.BOLD, 20));
		chkbxLagosChocoleteCake.setBounds(17, 291, 288, 25);
		panel_1_1.add(chkbxLagosChocoleteCake);
		
		TextField textField_6_6 = new TextField();
		textField_6_6.setText("              0");
		textField_6_6.setBounds(310, 291, 123, 25);
		panel_1_1.add(textField_6_6);
		
		JCheckBox chkKenyaChocoleteCake = new JCheckBox("Kenya Chocolete Cake");
		chkKenyaChocoleteCake.setBackground(new Color(176, 224, 230));
		chkKenyaChocoleteCake.setFont(new Font("Dialog", Font.BOLD, 20));
		chkKenyaChocoleteCake.setBounds(17, 332, 288, 25);
		panel_1_1.add(chkKenyaChocoleteCake);
		
		TextField textField_6_7 = new TextField();
		textField_6_7.setText("              0");
		textField_6_7.setBounds(311, 332, 122, 25);
		panel_1_1.add(textField_6_7);
		
		JCheckBox chkCarltonHillChocolete = new JCheckBox("Carlton Hill Chocolete Cake");
		chkCarltonHillChocolete.setBackground(new Color(176, 224, 230));
		chkCarltonHillChocolete.setFont(new Font("Dialog", Font.BOLD, 20));
		chkCarltonHillChocolete.setBounds(17, 375, 288, 25);
		panel_1_1.add(chkCarltonHillChocolete);
		
		TextField textField_6_8 = new TextField();
		textField_6_8.setText("              0");
		textField_6_8.setBounds(311, 375, 122, 25);
		panel_1_1.add(textField_6_8);
		
		JCheckBox chkQueenParkChocoleteCake = new JCheckBox("Queen,s Park Chocolete Cake");
		chkQueenParkChocoleteCake.setBackground(new Color(176, 224, 230));
		chkQueenParkChocoleteCake.setFont(new Font("Dialog", Font.BOLD, 20));
		chkQueenParkChocoleteCake.setBounds(17, 420, 288, 25);
		panel_1_1.add(chkQueenParkChocoleteCake);
		
		TextField textField_6_9 = new TextField();
		textField_6_9.setText("              0");
		textField_6_9.setBounds(311, 420, 122, 25);
		panel_1_1.add(textField_6_9);
		
		JCheckBox chkSwindonCare = new JCheckBox("Swindon Cake");
		chkSwindonCare.setBackground(new Color(176, 224, 230));
		chkSwindonCare.setFont(new Font("Dialog", Font.BOLD, 20));
		chkSwindonCare.setBounds(17, 168, 288, 25);
		panel_1_1.add(chkSwindonCare);
		
		JLabel lblText = new JLabel("Tax");
		lblText.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblText.setBounds(35, 478, 166, 39);
		panel_1_1.add(lblText);
		
		JLabel lblSubtotal = new JLabel("SubTotal");
		lblSubtotal.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblSubtotal.setBounds(35, 534, 166, 25);
		panel_1_1.add(lblSubtotal);
		
		JLabel lblTotal = new JLabel("Total");
		lblTotal.setFont(new Font("Tahoma", Font.BOLD, 23));
		lblTotal.setBounds(35, 582, 166, 25);
		panel_1_1.add(lblTotal);
		
		TextField textField_7 = new TextField();
		textField_7.setBounds(267, 478, 166, 29);
		panel_1_1.add(textField_7);
		
		TextField textField_1_2 = new TextField();
		textField_1_2.setBounds(267, 530, 166, 29);
		panel_1_1.add(textField_1_2);
		
		TextField textField_2_2 = new TextField();
		textField_2_2.setBounds(267, 578, 166, 29);
		panel_1_1.add(textField_2_2);
	}

	 {
		// TODO Auto-generated method stub
		
	}
	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "SwingAction");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
		}
	}
}
