package CustomerBilling2;

public class jtxtCustomer {

}
